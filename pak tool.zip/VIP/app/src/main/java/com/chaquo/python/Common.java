package com.chaquo.python;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/* loaded from: classes.dex */
public class Common {
    public static final List<String> ABIS;
    public static final String ABI_COMMON = "common";
    public static final String ASSET_APP = "app";
    public static final String ASSET_BOOTSTRAP = "bootstrap";
    public static final String ASSET_BOOTSTRAP_NATIVE = "bootstrap-native";
    public static final String ASSET_BUILD_JSON = "build.json";
    public static final String ASSET_CACERT = "cacert.pem";
    public static final String ASSET_DIR = "chaquopy";
    public static final String ASSET_REQUIREMENTS = "requirements";
    public static final String ASSET_STDLIB = "stdlib";
    public static final int COMPILE_SDK_VERSION = 30;
    public static final String DEFAULT_PYTHON_VERSION = "3.8";
    public static final int MIN_SDK_VERSION = 21;
    public static final String PYTHON_IMPLEMENTATION = "cp";
    public static final Map<String, String> PYTHON_VERSIONS;
    public static List<String> PYTHON_VERSIONS_SHORT;

    static {
        LinkedHashMap<String, String> linkedHashMap = new LinkedHashMap<>();
        PYTHON_VERSIONS = linkedHashMap;
        linkedHashMap.put("3.8.16", "0");
        linkedHashMap.put("3.9.13", "1");
        linkedHashMap.put("3.10.6", "1");
        linkedHashMap.put("3.11.0", "2");
        PYTHON_VERSIONS_SHORT = new ArrayList<>();
        for (String fullVersion : linkedHashMap.keySet()) {
            PYTHON_VERSIONS_SHORT.add(fullVersion.substring(0, fullVersion.lastIndexOf(46)));
        }
        ABIS = Arrays.asList("armeabi-v7a", "arm64-v8a", "x86", "x86_64");
    }

    public static String assetZip(String type) {
        return assetZip(type, null);
    }

    public static String assetZip(String type, String abi) {
        return abi == null ? type + ".imy" : type + "-" + abi + ".imy";
    }
}
