package com.chaquo.python;

import java.lang.reflect.Field;
import java.lang.reflect.Member;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/* loaded from: classes.dex */
public class Reflector {
    private static Map<Class<?>, Reflector> instances = new HashMap();
    private Map<String, Class<?>> classes;
    private Map<String, Field> fields;
    private final Class<?> klass;
    private Map<String, Member> methods;
    private Map<String, List<Member>> multipleMethods;

    public static Reflector getInstance(Class<?> klass) {
        Reflector reflector = instances.get(klass);
        if (reflector != null) {
            return reflector;
        }
        Reflector reflector2 = new Reflector(klass);
        instances.put(klass, reflector2);
        return reflector2;
    }

    private Reflector(Class<?> klass) {
        this.klass = klass;
    }

    public synchronized String[] dir() {
        Set<String> names;
        if (this.methods == null) {
            loadMethods();
        }
        if (this.fields == null) {
            loadFields();
        }
        if (this.classes == null) {
            loadClasses();
        }
        names = new HashSet<>();
        names.addAll(this.methods.keySet());
        names.addAll(this.multipleMethods.keySet());
        names.addAll(this.fields.keySet());
        names.addAll(this.classes.keySet());
        return (String[]) names.toArray(new String[0]);
    }

    public synchronized Member[] getMethods(String name) {
        if (this.methods == null) {
            loadMethods();
        }
        List<Member> list = this.multipleMethods.get(name);
        if (list != null) {
            return (Member[]) list.toArray(new Member[0]);
        }
        Member method = this.methods.get(name);
        if (method == null) {
            return null;
        }
        return new Member[]{method};
    }

    private void loadMethods() {
        this.methods = new HashMap();
        this.multipleMethods = new HashMap();
        for (Member c : this.klass.getDeclaredConstructors()) {
            if (isAccessible(c)) {
                loadMethod(c, "<init>");
            }
        }
        for (Method m : getDeclaredMethods()) {
            if (isAccessible(m)) {
                loadMethod(m, m.getName());
            }
        }
    }

    private Collection<Method> getDeclaredMethods() {
        try {
            return Arrays.asList(this.klass.getDeclaredMethods());
        } catch (NoClassDefFoundError e) {
            Set<Method> result = new HashSet<>();
            try {
                for (Method m : this.klass.getMethods()) {
                    if (m.getDeclaringClass() == this.klass) {
                        try {
                            m.getReturnType();
                            m.getParameterTypes();
                            result.add(m);
                        } catch (NoClassDefFoundError e2) {
                        }
                    }
                }
            } catch (NoClassDefFoundError e3) {
            }
            for (Class<?> c = this.klass.getSuperclass(); c != null; c = c.getSuperclass()) {
                for (Method inherited : getInstance(c).getDeclaredMethods()) {
                    try {
                        result.add(this.klass.getDeclaredMethod(inherited.getName(), inherited.getParameterTypes()));
                    } catch (NoSuchMethodException e4) {
                    }
                }
            }
            return result;
        }
    }

    private void loadMethod(Member m, String name) {
        Member mExisting = this.methods.remove(name);
        if (mExisting != null) {
            List<Member> list = new ArrayList<>();
            list.add(mExisting);
            list.add(m);
            this.multipleMethods.put(name, list);
            return;
        }
        List<Member> list2 = this.multipleMethods.get(name);
        if (list2 != null) {
            list2.add(m);
        } else {
            this.methods.put(name, m);
        }
    }

    public synchronized Field getField(String name) {
        if (this.fields == null) {
            loadFields();
        }
        return this.fields.get(name);
    }

    private void loadFields() {
        this.fields = new HashMap();
        for (Field f : getDeclaredFields()) {
            if (isAccessible(f)) {
                this.fields.put(f.getName(), f);
            }
        }
    }

    private Collection<Field> getDeclaredFields() {
        try {
            return Arrays.asList(this.klass.getDeclaredFields());
        } catch (NoClassDefFoundError e) {
            Set<Field> result = new HashSet<>();
            try {
                for (Field f : this.klass.getFields()) {
                    if (f.getDeclaringClass() == this.klass) {
                        try {
                            f.getType();
                            result.add(f);
                        } catch (NoClassDefFoundError e2) {
                        }
                    }
                }
            } catch (NoClassDefFoundError e3) {
            }
            return result;
        }
    }

    public synchronized Class<?> getNestedClass(String name) {
        if (this.classes == null) {
            loadClasses();
        }
        return this.classes.get(name);
    }

    private void loadClasses() {
        this.classes = new HashMap();
        for (Class<?> k : this.klass.getDeclaredClasses()) {
            if (isAccessible(k.getModifiers())) {
                String simpleName = k.getSimpleName();
                if (!simpleName.isEmpty()) {
                    this.classes.put(simpleName, k);
                }
            }
        }
    }

    private boolean isAccessible(Member m) {
        return isAccessible(m.getModifiers()) && !m.isSynthetic();
    }

    private boolean isAccessible(int modifiers) {
        return (modifiers & 5) != 0;
    }
}
