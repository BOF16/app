package com.chaquo.python;

import java.lang.ref.WeakReference;
import java.lang.reflect.UndeclaredThrowableException;
import java.util.AbstractMap;
import java.util.AbstractSet;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Objects;
import java.util.Set;

/* loaded from: classes.dex */
public class PyObject extends AbstractMap<String, PyObject> implements AutoCloseable {
    private static final Map<Long, WeakReference<PyObject>> cache = new HashMap();
    public long addr;

    private native long callAttrThrowsNative(String str, Object... objArr) throws Throwable;

    private native long callThrowsNative(Object... objArr) throws Throwable;

    private native void closeNative();

    private native boolean containsKeyNative(String str);

    /* JADX INFO: Access modifiers changed from: private */
    public native List<String> dir();

    private static native long fromJavaNative(Object obj);

    private native long getNative(String str);

    private native long putNative(String str, Object obj);

    private native long removeNative(String str);

    private native long typeNative();

    @Override // java.util.AbstractMap, java.util.Map
    public native boolean equals(Object obj);

    @Override // java.util.AbstractMap, java.util.Map
    public native int hashCode();

    public native long id();

    public native String repr();

    public native boolean toBoolean();

    public native byte toByte();

    public native char toChar();

    public native double toDouble();

    public native float toFloat();

    public native int toInt();

    public native <T> T toJava(Class<T> cls);

    public native long toLong();

    public native short toShort();

    @Override // java.util.AbstractMap
    public native String toString();

    public static PyObject getInstance(long addr) {
        PyObject po;
        if (addr == 0) {
            return null;
        }
        Map<Long, WeakReference<PyObject>> map = cache;
        synchronized (map) {
            WeakReference<PyObject> wr = map.get(Long.valueOf(addr));
            if (wr != null && (po = wr.get()) != null) {
                return po;
            }
            PyObject po2 = new PyObject(addr);
            map.put(Long.valueOf(addr), new WeakReference<>(po2));
            return po2;
        }
    }

    private PyObject(long addr) {
        this.addr = addr;
    }

    @Override // java.lang.AutoCloseable
    public void close() {
        PyObject po;
        if (this.addr == 0) {
            return;
        }
        Map<Long, WeakReference<PyObject>> map = cache;
        synchronized (map) {
            WeakReference<PyObject> wr = map.remove(Long.valueOf(this.addr));
            if (wr != null && (po = wr.get()) != null && po != this) {
                map.put(Long.valueOf(this.addr), wr);
            }
        }
        closeNative();
        this.addr = 0L;
    }

    public static PyObject fromJava(Object o) {
        return getInstance(fromJavaNative(o));
    }

    public List<PyObject> asList() {
        return new PyList(this);
    }

    public Map<PyObject, PyObject> asMap() {
        return new PyMap(this);
    }

    public Set<PyObject> asSet() {
        return new PySet(this);
    }

    public PyObject type() {
        return (PyObject) Objects.requireNonNull(getInstance(typeNative()));
    }

    public PyObject call(Object... args) {
        try {
            return callThrows(args);
        } catch (PyException e) {
            throw e;
        } catch (Throwable e2) {
            throw new PyException(e2);
        }
    }

    public PyObject callThrows(Object... args) throws Throwable {
        return getInstance(callThrowsNative(args));
    }

    public PyObject callAttr(String key, Object... args) {
        try {
            return callAttrThrows(key, args);
        } catch (PyException e) {
            throw e;
        } catch (Throwable e2) {
            throw new PyException(e2);
        }
    }

    public PyObject callAttrThrows(String key, Object... args) throws Throwable {
        return getInstance(callAttrThrowsNative(key, args));
    }

    public static PyObject _chaquopyCall(StaticProxy sp, String name, Object... args) {
        try {
            return fromJava(sp).callAttrThrows(name, args);
        } catch (Error e) {
            throw e;
        } catch (RuntimeException e2) {
            throw e2;
        } catch (Throwable e3) {
            throw new UndeclaredThrowableException(e3);
        }
    }

    @Override // java.util.AbstractMap, java.util.Map
    public void clear() {
        super.clear();
    }

    @Override // java.util.AbstractMap, java.util.Map
    public boolean isEmpty() {
        return super.isEmpty();
    }

    @Override // java.util.AbstractMap, java.util.Map
    public boolean containsKey(Object key) {
        return containsKeyNative((String) key);
    }

    @Override // java.util.AbstractMap, java.util.Map
    public boolean containsValue(Object o) {
        return super.containsValue(fromJava(o));
    }

    @Override // java.util.AbstractMap, java.util.Map
    public PyObject get(Object key) {
        return getInstance(getNative((String) key));
    }

    @Override // java.util.AbstractMap, java.util.Map
    public PyObject put(String key, PyObject value) {
        return put(key, (Object) value);
    }

    public PyObject put(String key, Object value) {
        return getInstance(putNative(key, value));
    }

    @Override // java.util.AbstractMap, java.util.Map
    public PyObject remove(Object key) {
        return getInstance(removeNative((String) key));
    }

    @Override // java.util.AbstractMap, java.util.Map
    public Set<String> keySet() {
        return super.keySet();
    }

    /* renamed from: com.chaquo.python.PyObject$1, reason: invalid class name */
    class AnonymousClass1 extends AbstractSet<Map.Entry<String, PyObject>> {
        AnonymousClass1() {
        }

        @Override // java.util.AbstractCollection, java.util.Collection, java.util.Set
        public int size() {
            return PyObject.this.dir().size();
        }

        /* renamed from: com.chaquo.python.PyObject$1$1, reason: invalid class name and collision with other inner class name */
        class C00061 implements Iterator<Map.Entry<String, PyObject>> {
            int i = 0;
            List<String> keys;

            C00061() {
                this.keys = PyObject.this.dir();
            }

            @Override // java.util.Iterator
            public boolean hasNext() {
                return this.i < this.keys.size();
            }

            @Override // java.util.Iterator
            public Map.Entry<String, PyObject> next() {
                if (!hasNext()) {
                    throw new NoSuchElementException();
                }
                Map.Entry<String, PyObject> entry = new Map.Entry<String, PyObject>() { // from class: com.chaquo.python.PyObject.1.1.1
                    String key;

                    {
                        this.key = C00061.this.keys.get(C00061.this.i);
                    }

                    @Override // java.util.Map.Entry
                    public String getKey() {
                        return this.key;
                    }

                    /* JADX WARN: Can't rename method to resolve collision */
                    @Override // java.util.Map.Entry
                    public PyObject getValue() {
                        return PyObject.this.get((Object) this.key);
                    }

                    @Override // java.util.Map.Entry
                    public PyObject setValue(PyObject newValue) {
                        return PyObject.this.put(this.key, newValue);
                    }
                };
                this.i++;
                return entry;
            }

            @Override // java.util.Iterator
            public void remove() {
                PyObject.this.remove((Object) this.keys.get(this.i - 1));
            }
        }

        @Override // java.util.AbstractCollection, java.util.Collection, java.lang.Iterable, java.util.Set
        public Iterator<Map.Entry<String, PyObject>> iterator() {
            return new C00061();
        }
    }

    @Override // java.util.AbstractMap, java.util.Map
    public Set<Map.Entry<String, PyObject>> entrySet() {
        return new AnonymousClass1();
    }

    protected void finalize() throws Throwable {
        close();
        super.finalize();
    }
}
