package com.chaquo.python;

import java.util.AbstractList;

/* loaded from: classes.dex */
class PyList extends AbstractList<PyObject> {
    private final MethodCache methods;
    private final PyObject obj;

    public PyList(PyObject obj) {
        this.obj = obj;
        MethodCache methodCache = new MethodCache(obj);
        this.methods = methodCache;
        methodCache.get("__getitem__");
        methodCache.get("__len__");
    }

    private void checkLowerBound(int index) {
        if (index < 0) {
            throw outOfBounds(index);
        }
    }

    private RuntimeException maybeOutOfBounds(int index, PyException e) {
        if (e.getMessage().startsWith("IndexError:")) {
            return outOfBounds(index);
        }
        return e;
    }

    private IndexOutOfBoundsException outOfBounds(int index) {
        return new IndexOutOfBoundsException("Invalid index " + index + ", size is " + size());
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.List
    public int size() {
        return this.methods.get("__len__").call(new Object[0]).toInt();
    }

    @Override // java.util.AbstractList, java.util.List
    public PyObject get(int index) {
        checkLowerBound(index);
        try {
            return this.methods.get("__getitem__").call(Integer.valueOf(index));
        } catch (PyException e) {
            throw maybeOutOfBounds(index, e);
        }
    }

    @Override // java.util.AbstractList, java.util.List
    public PyObject set(int index, PyObject element) {
        PyObject oldElement = get(index);
        this.methods.get("__setitem__").call(Integer.valueOf(index), element);
        return oldElement;
    }

    @Override // java.util.AbstractList, java.util.List
    public void add(int index, PyObject element) {
        checkLowerBound(index);
        if (index > size()) {
            throw outOfBounds(index);
        }
        this.methods.get("insert").call(Integer.valueOf(index), element);
    }

    @Override // java.util.AbstractList, java.util.List
    public PyObject remove(int index) {
        checkLowerBound(index);
        try {
            return this.methods.get("pop").call(Integer.valueOf(index));
        } catch (PyException e) {
            throw maybeOutOfBounds(index, e);
        }
    }

    @Override // java.util.AbstractList, java.util.AbstractCollection, java.util.Collection, java.util.List
    public void clear() {
        this.methods.get("clear").call(new Object[0]);
    }
}
