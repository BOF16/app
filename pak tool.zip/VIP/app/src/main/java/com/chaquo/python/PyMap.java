package com.chaquo.python;

import java.util.AbstractMap;
import java.util.AbstractSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/* loaded from: classes.dex */
class PyMap extends AbstractMap<PyObject, PyObject> {
    private final MethodCache methods;
    private final PyObject obj;

    public PyMap(PyObject obj) {
        this.obj = obj;
        MethodCache methodCache = new MethodCache(obj);
        this.methods = methodCache;
        methodCache.get("__contains__");
        methodCache.get("__getitem__");
        methodCache.get("__iter__");
        methodCache.get("__len__");
    }

    /* renamed from: com.chaquo.python.PyMap$1, reason: invalid class name */
    class AnonymousClass1 extends AbstractSet<Map.Entry<PyObject, PyObject>> {
        AnonymousClass1() {
        }

        @Override // java.util.AbstractCollection, java.util.Collection, java.util.Set
        public int size() {
            return PyMap.this.methods.get("__len__").call(new Object[0]).toInt();
        }

        @Override // java.util.AbstractCollection, java.util.Collection, java.lang.Iterable, java.util.Set
        public Iterator<Map.Entry<PyObject, PyObject>> iterator() {
            return new PyIterator<Map.Entry<PyObject, PyObject>>(PyMap.this.methods) { // from class: com.chaquo.python.PyMap.1.1
                /* JADX INFO: Access modifiers changed from: protected */
                @Override // com.chaquo.python.PyIterator
                public Map.Entry<PyObject, PyObject> makeNext(final PyObject key) {
                    return new Map.Entry<PyObject, PyObject>() { // from class: com.chaquo.python.PyMap.1.1.1
                        /* JADX WARN: Can't rename method to resolve collision */
                        @Override // java.util.Map.Entry
                        public PyObject getKey() {
                            return key;
                        }

                        /* JADX WARN: Can't rename method to resolve collision */
                        @Override // java.util.Map.Entry
                        public PyObject getValue() {
                            return PyMap.this.get((Object) key);
                        }

                        @Override // java.util.Map.Entry
                        public PyObject setValue(PyObject value) {
                            return PyMap.this.put(key, value);
                        }
                    };
                }
            };
        }

        @Override // java.util.AbstractCollection, java.util.Collection, java.util.Set
        public void clear() {
            PyMap.this.methods.get("clear").call(new Object[0]);
        }
    }

    @Override // java.util.AbstractMap, java.util.Map
    public Set<Map.Entry<PyObject, PyObject>> entrySet() {
        return new AnonymousClass1();
    }

    @Override // java.util.AbstractMap, java.util.Map
    public boolean containsKey(Object key) {
        return this.methods.get("__contains__").call(key).toBoolean();
    }

    @Override // java.util.AbstractMap, java.util.Map
    public PyObject get(Object key) {
        try {
            return this.methods.get("__getitem__").call(key);
        } catch (PyException e) {
            if (e.getMessage().startsWith("KeyError:")) {
                return null;
            }
            throw e;
        }
    }

    @Override // java.util.AbstractMap, java.util.Map
    public PyObject put(PyObject key, PyObject value) {
        PyObject oldElement = get((Object) key);
        this.methods.get("__setitem__").call(key, value);
        return oldElement;
    }

    @Override // java.util.AbstractMap, java.util.Map
    public PyObject remove(Object key) {
        return this.methods.get("pop").call(key, null);
    }
}
