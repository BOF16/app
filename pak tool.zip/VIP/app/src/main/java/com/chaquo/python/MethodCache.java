package com.chaquo.python;

import java.util.HashMap;
import java.util.Map;

/* loaded from: classes.dex */
class MethodCache {
    private Map<String, PyObject> cache = new HashMap();
    private PyObject obj;

    public MethodCache(PyObject obj) {
        this.obj = obj;
    }

    public PyObject get(String name) {
        PyObject value = this.cache.get(name);
        if (value == null) {
            value = this.obj.get((Object) name);
            if (value == null) {
                throw new UnsupportedOperationException(String.format("'%s' object has no attribute '%s'", this.obj.type().get((Object) "__name__"), name));
            }
            this.cache.put(name, value);
        }
        return value;
    }
}
