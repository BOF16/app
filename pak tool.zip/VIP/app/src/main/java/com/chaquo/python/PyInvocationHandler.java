package com.chaquo.python;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;

/* loaded from: classes.dex */
public class PyInvocationHandler implements InvocationHandler {
    private PyObject dict;
    private PyObject type;

    public PyInvocationHandler(PyObject type) {
        this.type = type;
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    @Override // java.lang.reflect.InvocationHandler
    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
        char c;
        String methodName = method.getName();
        switch (methodName.hashCode()) {
            case -983358751:
                if (methodName.equals("_chaquopySetDict")) {
                    c = 2;
                    break;
                }
                c = 65535;
                break;
            case 1251498965:
                if (methodName.equals("_chaquopyGetDict")) {
                    c = 1;
                    break;
                }
                c = 65535;
                break;
            case 1251991385:
                if (methodName.equals("_chaquopyGetType")) {
                    c = 0;
                    break;
                }
                c = 65535;
                break;
            default:
                c = 65535;
                break;
        }
        switch (c) {
            case 0:
                return this.type;
            case 1:
                return this.dict;
            case 2:
                this.dict = (PyObject) args[0];
                return null;
            default:
                PyObject self = PyObject.fromJava(proxy);
                if (args == null) {
                    args = new Object[0];
                }
                PyObject result = self.callAttrThrows(methodName, args);
                if (result == null) {
                    return null;
                }
                return result.toJava(method.getReturnType());
        }
    }
}
