package com.chaquo.python;

import java.util.Objects;

/* loaded from: classes.dex */
public class Python {
    private static boolean failed;
    private static Python instance = new Python();
    private static Platform platform;

    private native long getModuleNative(String str);

    private static native void startNative(Platform platform2, String str);

    public static class Platform {
        public String getPath() {
            return null;
        }

        public void onStart(Python py) {
        }
    }

    public static synchronized Python getInstance() {
        Python python2;
        synchronized (Python.class) {
            if (!isStarted()) {
                start(new GenericPlatform());
            }
            python2 = instance;
        }
        return python2;
    }

    public static synchronized void start(Platform platform2) {
        synchronized (Python.class) {
            if (isStarted()) {
                throw new IllegalStateException("Python already started");
            }
            if (failed) {
                throw new IllegalStateException("Python startup previously failed, and cannot be retried");
            }
            try {
                startNative(platform2, platform2.getPath());
                platform2.onStart(instance);
                platform = platform2;
            } catch (Throwable e) {
                failed = true;
                throw e;
            }
        }
    }

    public static synchronized Platform getPlatform() {
        Platform platform2;
        synchronized (Python.class) {
            platform2 = platform;
        }
        return platform2;
    }

    public static synchronized boolean isStarted() {
        boolean z;
        synchronized (Python.class) {
            z = platform != null;
        }
        return z;
    }

    private Python() {
    }

    public PyObject getModule(String name) {
        return (PyObject) Objects.requireNonNull(PyObject.getInstance(getModuleNative(name)));
    }

    public PyObject getBuiltins() {
        return getModule("builtins");
    }
}
