package com.chaquo.python;

import java.util.AbstractSet;
import java.util.Iterator;

/* loaded from: classes.dex */
class PySet extends AbstractSet<PyObject> {
    private final MethodCache methods;
    private final PyObject obj;

    public PySet(PyObject obj) {
        this.obj = obj;
        MethodCache methodCache = new MethodCache(obj);
        this.methods = methodCache;
        methodCache.get("__contains__");
        methodCache.get("__iter__");
        methodCache.get("__len__");
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.Set
    public int size() {
        return this.methods.get("__len__").call(new Object[0]).toInt();
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.Set
    public boolean contains(Object element) {
        return this.methods.get("__contains__").call(element).toBoolean();
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.lang.Iterable, java.util.Set
    public Iterator<PyObject> iterator() {
        return new PyIterator<PyObject>(this.methods) { // from class: com.chaquo.python.PySet.1
            /* JADX INFO: Access modifiers changed from: protected */
            /* JADX WARN: Can't rename method to resolve collision */
            @Override // com.chaquo.python.PyIterator
            public PyObject makeNext(PyObject element) {
                return element;
            }
        };
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.Set
    public boolean add(PyObject element) {
        PyObject method = this.methods.get("add");
        if (contains(element)) {
            return false;
        }
        method.call(element);
        return true;
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.Set
    public boolean remove(Object element) {
        try {
            this.methods.get("remove").call(element);
            return true;
        } catch (PyException e) {
            if (e.getMessage().startsWith("KeyError:")) {
                return false;
            }
            throw e;
        }
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.Set
    public void clear() {
        this.methods.get("clear").call(new Object[0]);
    }
}
