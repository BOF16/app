package com.chaquo.python.android;

import android.app.Application;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.AssetManager;
import android.os.Build;
import com.chaquo.python.Common;
import com.chaquo.python.Python;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import org.json.JSONException;
import org.json.JSONObject;

/* loaded from: classes.dex */
public class AndroidPlatform extends Python.Platform {
    public static String ABI;
    private AssetManager am;
    private JSONObject buildJson;
    public Application mContext;
    private SharedPreferences sp;
    private static final String[] OBSOLETE_FILES = {"app.zip", "requirements.zip", "chaquopy.mp3", "stdlib.mp3", "chaquopy.zip", "lib-dynload", "stdlib.zip", "bootstrap.zip", "stdlib-common.zip", "ticket.txt"};
    private static final String[] OBSOLETE_CACHE = {"AssetFinder"};

    public native void redirectStdioToLogcat();

    public AndroidPlatform(Context context) {
        Application application = (Application) context.getApplicationContext();
        this.mContext = application;
        this.sp = application.getSharedPreferences(Common.ASSET_DIR, 0);
        this.am = this.mContext.getAssets();
        try {
            this.buildJson = new JSONObject(streamToString(this.am.open("chaquopy/build.json")));
            loadNativeLibs();
            List<String> supportedAbis = new ArrayList<>();
            Collections.addAll(supportedAbis, Build.SUPPORTED_ABIS);
            for (String abi : supportedAbis) {
                try {
                    this.am.open("chaquopy/" + Common.assetZip(Common.ASSET_STDLIB, abi));
                    ABI = abi;
                    break;
                } catch (IOException e) {
                }
            }
            if (ABI == null) {
                throw new RuntimeException("None of this device's ABIs " + supportedAbis + " are supported by this app.");
            }
        } catch (IOException | JSONException e2) {
            throw new RuntimeException(e2);
        }
    }

    public Application getApplication() {
        return this.mContext;
    }

    @Override // com.chaquo.python.Python.Platform
    public String getPath() {
        String path = "";
        String assetDir = this.mContext.getFilesDir() + "/" + Common.ASSET_DIR;
        List<String> bootstrapAssets = new ArrayList<>(Arrays.asList(Common.assetZip(Common.ASSET_STDLIB, Common.ABI_COMMON), Common.assetZip(Common.ASSET_BOOTSTRAP), "bootstrap-native/" + ABI));
        for (int i = 0; i < bootstrapAssets.size(); i++) {
            path = path + assetDir + "/" + bootstrapAssets.get(i);
            if (i < bootstrapAssets.size() - 1) {
                path = path + ":";
            }
        }
        Collections.addAll(bootstrapAssets, Common.ASSET_CACERT);
        try {
            deleteObsolete(this.mContext.getFilesDir(), OBSOLETE_FILES);
            deleteObsolete(this.mContext.getCacheDir(), OBSOLETE_CACHE);
            extractAssets(bootstrapAssets);
            return path;
        } catch (IOException | JSONException e) {
            throw new RuntimeException(e);
        }
    }

    private void deleteObsolete(File baseDir, String[] filenames) {
        for (String filename : filenames) {
            deleteRecursive(new File(baseDir, "chaquopy/" + filename.replace("<abi>", ABI)));
        }
    }

    @Override // com.chaquo.python.Python.Platform
    public void onStart(Python py) {
        String[] appPath = {Common.ASSET_APP, Common.ASSET_REQUIREMENTS, "stdlib-" + ABI};
        py.getModule("java.android").callAttr("initialize", this.mContext, this.buildJson, appPath);
    }

    private void extractAssets(List<String> assets) throws IOException, JSONException {
        JSONObject assetsJson = this.buildJson.getJSONObject("assets");
        Set<String> unextracted = new HashSet<>(assets);
        Set<String> directories = new HashSet<>();
        SharedPreferences.Editor spe = this.sp.edit();
        Iterator<String> i = assetsJson.keys();
        while (i.hasNext()) {
            String path = i.next();
            for (String ea : assets) {
                if (path.equals(ea) || path.startsWith(ea + "/")) {
                    extractAsset(assetsJson, spe, path);
                    unextracted.remove(ea);
                    if (path.startsWith(ea + "/")) {
                        directories.add(ea);
                    }
                }
            }
        }
        if (!unextracted.isEmpty()) {
            throw new RuntimeException("Failed to find assets: " + unextracted);
        }
        for (String dir : directories) {
            cleanExtractedDir(dir, assetsJson);
        }
        spe.apply();
    }

    private void extractAsset(JSONObject assetsJson, SharedPreferences.Editor spe, String path) throws IOException, JSONException {
        String fullPath = "chaquopy/" + path;
        File outFile = new File(this.mContext.getFilesDir(), fullPath);
        String spKey = "asset." + path;
        String newHash = assetsJson.getString(path);
        if (outFile.exists() && this.sp.getString(spKey, "").equals(newHash)) {
            return;
        }
        outFile.delete();
        File outDir = outFile.getParentFile();
        if (!outDir.exists()) {
            outDir.mkdirs();
            if (!outDir.isDirectory()) {
                throw new IOException("Failed to create " + outDir);
            }
        }
        InputStream inStream = this.am.open(fullPath);
        File tmpFile = new File(outDir, outFile.getName() + ".tmp");
        tmpFile.delete();
        OutputStream outStream = new FileOutputStream(tmpFile);
        try {
            transferStream(inStream, outStream);
            outStream.close();
            if (!tmpFile.renameTo(outFile)) {
                throw new IOException("Failed to create " + outFile);
            }
            spe.putString(spKey, newHash);
        } catch (Throwable th) {
            outStream.close();
            throw th;
        }
    }

    private void cleanExtractedDir(String dir, JSONObject assetsJson) {
        File outDir = new File(this.mContext.getFilesDir(), "chaquopy/" + dir);
        for (String name : outDir.list()) {
            File outFile = new File(outDir, name);
            if (outFile.isDirectory()) {
                cleanExtractedDir(dir + "/" + name, assetsJson);
            } else if (!assetsJson.has(dir + "/" + name)) {
                outFile.delete();
            }
        }
    }

    private void deleteRecursive(File file) {
        File[] children = file.listFiles();
        if (children != null) {
            for (File child : children) {
                deleteRecursive(child);
            }
        }
        file.delete();
    }

    private void transferStream(InputStream in, OutputStream out) throws IOException {
        byte[] buffer = new byte[1048576];
        int len = in.read(buffer);
        while (len != -1) {
            out.write(buffer, 0, len);
            len = in.read(buffer);
        }
    }

    private String streamToString(InputStream in) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(in));
        StringBuilder out = new StringBuilder();
        while (true) {
            String line = reader.readLine();
            if (line != null) {
                out.append(line);
                out.append("\n");
            } else {
                return out.toString();
            }
        }
    }

    private void loadNativeLibs() throws JSONException {
        System.loadLibrary("crypto_chaquopy");
        System.loadLibrary("ssl_chaquopy");
        System.loadLibrary("sqlite3_chaquopy");
        System.loadLibrary("python" + this.buildJson.getString("python_version"));
        System.loadLibrary("chaquopy_java");
    }
}
