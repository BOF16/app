package com.chaquo.python;

/* loaded from: classes.dex */
public class Kwarg {
    public String key;
    public Object value;

    public Kwarg(String key, Object value) {
        this.key = key;
        this.value = value;
    }
}
