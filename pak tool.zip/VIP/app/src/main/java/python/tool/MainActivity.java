package python.tool;

import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;
import com.google.android.material.tabs.TabLayout;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;

public final class MainActivity extends AppCompatActivity {
    private static final int STORAGE_PERMISSION_REQUEST = 100;
    private static final long PROGRESS_REFRESH_MS = 500L;

    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private boolean taskRunning;
    private ProgressBar progressBar;
    private TextView resultText;
    private TextView selectedPakText;
    private View pakSection;
    private View luaSection;
    private File progressFile;
    private File originalPakFolder;
    private File editLuaFolder;
    private File resultFolder;
    private File openLuaFolder;
    private File compiledLuaFolder;
    private File originalLuaFolder;
    private File selectedPak;
    private File templateFile;
    private File luacFile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bindViews();
        createWorkingFolders();
        copyRuntimeAssets();
        requestStorageAccessIfNeeded();
        configureTabs();
        configureButtons();
    }

    private void bindViews() {
        resultText = findViewById(R.id.result_text);
        selectedPakText = findViewById(R.id.selected_pak_text);
        progressBar = findViewById(R.id.progress_bar);
        pakSection = findViewById(R.id.section_pak);
        luaSection = findViewById(R.id.section_lua);
    }

    private void createWorkingFolders() {
        File root = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "Mehdi/Mehdi TOOL");
        originalPakFolder = ensureDirectory(new File(root, "ORIGNAL_PAK"));
        editLuaFolder = ensureDirectory(new File(root, "EDITLUA"));
        resultFolder = ensureDirectory(new File(root, "RESULT"));
        openLuaFolder = ensureDirectory(new File(root, "OPEN_LUA"));
        compiledLuaFolder = ensureDirectory(new File(root, "COMPILED_LUA"));
        originalLuaFolder = ensureDirectory(new File(root, "LUA_ORIGINAL"));
        progressFile = new File(root, "progress.txt");
    }

    private File ensureDirectory(File directory) {
        if (!directory.exists()) directory.mkdirs();
        return directory;
    }

    private void copyRuntimeAssets() {
        File runtimeFolder = ensureDirectory(new File(getFilesDir(), "assets"));
        templateFile = copyAsset("template.lua", new File(runtimeFolder, "template.lua"));
        copyAsset("unluac.jar", new File(runtimeFolder, "unluac.jar"));
        luacFile = new File(getApplicationInfo().nativeLibraryDir, "libluac.so");
        if (luacFile.exists()) luacFile.setExecutable(true, false);
    }

    private File copyAsset(String assetName, File destination) {
        try (InputStream input = getAssets().open(assetName); FileOutputStream output = new FileOutputStream(destination)) {
            byte[] buffer = new byte[8192];
            int read;
            while ((read = input.read(buffer)) != -1) output.write(buffer, 0, read);
        } catch (IOException error) {
            showToast("تعذر تجهيز ملف التشغيل: " + assetName);
        }
        return destination;
    }

    private void requestStorageAccessIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (!Environment.isExternalStorageManager()) {
                showToast("يرجى منح صلاحية الوصول الكامل للملفات");
                openAllFilesAccessSettings();
            }
        } else if (ContextCompat.checkSelfPermission(this, "android.permission.WRITE_EXTERNAL_STORAGE") != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{"android.permission.READ_EXTERNAL_STORAGE", "android.permission.WRITE_EXTERNAL_STORAGE"}, STORAGE_PERMISSION_REQUEST);
        }
    }

    private void openAllFilesAccessSettings() {
        try {
            Intent intent = new Intent("android.settings.MANAGE_APP_ALL_FILES_ACCESS_PERMISSION");
            intent.setData(Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        } catch (Exception ignored) {
            startActivity(new Intent("android.settings.MANAGE_ALL_FILES_ACCESS_PERMISSION"));
        }
    }

    private void configureTabs() {
        TabLayout tabs = findViewById(R.id.tab_layout);
        tabs.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override public void onTabSelected(TabLayout.Tab tab) {
                boolean showPak = tab.getPosition() == 0;
                pakSection.setVisibility(showPak ? View.VISIBLE : View.GONE);
                luaSection.setVisibility(showPak ? View.GONE : View.VISIBLE);
            }
            @Override public void onTabUnselected(TabLayout.Tab tab) { }
            @Override public void onTabReselected(TabLayout.Tab tab) { }
        });
    }

    private void configureButtons() {
        findViewById(R.id.btn_pick_pak).setOnClickListener(view -> choosePakFile());
        findViewById(R.id.btn_unpack).setOnClickListener(view -> runAction("unpack", ""));
        findViewById(R.id.btn_repack_custom).setOnClickListener(view -> runAction("repack_custom", ""));
        findViewById(R.id.btn_stealth_repack).setOnClickListener(view -> chooseLuaFile());
        findViewById(R.id.btn_fix_crc).setOnClickListener(view -> runAction("fix_checksum", ""));
        findViewById(R.id.btn_compile_lua).setOnClickListener(view -> runAction("compile_lua", ""));
        findViewById(R.id.btn_decompile_lua).setOnClickListener(view -> runAction("decompile_lua", ""));
    }

    private void choosePakFile() {
        File[] files = originalPakFolder.listFiles((directory, name) -> name.toLowerCase().endsWith(".pak") && new File(directory, name).isFile());
        showFileChooser(files, "اختيار ملف PAK", file -> {
            if (file.length() == 0) { showToast("الملف فارغ"); return; }
            selectedPak = file;
            selectedPakText.setText("تم اختيار PAK:\n" + file.getAbsolutePath());
        });
    }

    private void chooseLuaFile() {
        if (!requirePak()) return;
        File[] files = editLuaFolder.listFiles((directory, name) -> {
            String lower = name.toLowerCase();
            return lower.endsWith(".lua") || lower.endsWith(".luac");
        });
        showFileChooser(files, "اختيار ملف Lua للتعديل الداخلي", file -> runAction("inplace_repack", file.getName()));
    }

    private void showFileChooser(File[] files, String title, FileSelectionCallback callback) {
        if (files == null || files.length == 0) { showToast("لا توجد ملفات مناسبة"); return; }
        String[] labels = new String[files.length];
        for (int i = 0; i < files.length; i++) labels[i] = files[i].getName() + " (" + formatSize(files[i].length()) + ")";
        new AlertDialog.Builder(this).setTitle(title).setItems(labels, (dialog, which) -> callback.onSelected(files[which])).setNegativeButton("إلغاء", null).show();
    }

    private boolean requirePak() {
        if (selectedPak == null || !selectedPak.isFile()) { showToast("اختر ملف PAK أولاً"); return false; }
        return true;
    }

    private void runAction(String action, String argument) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && !Environment.isExternalStorageManager()) {
            showToast("امنح صلاحية الوصول الكامل للملفات أولاً");
            openAllFilesAccessSettings();
            return;
        }
        if ((action.equals("unpack") || action.equals("repack_custom") || action.equals("fix_checksum") || action.equals("inplace_repack")) && !requirePak()) return;
        if (progressFile.exists()) progressFile.delete();
        progressBar.setVisibility(View.VISIBLE);
        resultText.setText("جاري التنفيذ: " + action + "...\nانتظر قليلاً");
        setActionButtonsEnabled(false);
        startProgressWatcher();

        new Thread(() -> {
            String result;
            try {
                if (!Python.isStarted()) Python.start(new AndroidPlatform(this));
                result = Python.getInstance().getModule("boot").callAttr("run_action", action,
                        selectedPak == null ? "" : selectedPak.getAbsolutePath(),
                        editLuaFolder.getAbsolutePath(), resultFolder.getAbsolutePath(), openLuaFolder.getAbsolutePath(),
                        compiledLuaFolder.getAbsolutePath(), originalPakFolder.getAbsolutePath(), templateFile.getAbsolutePath(),
                        luacFile.getAbsolutePath(), originalLuaFolder.getAbsolutePath(), argument).toString();
            } catch (Exception error) {
                result = "فشل التنفيذ: " + error.getMessage();
            }
            String finalResult = result;
            mainHandler.post(() -> finishAction(finalResult));
        }).start();
    }

    private void startProgressWatcher() {
        taskRunning = true;
        mainHandler.post(new Runnable() {
            @Override public void run() {
                if (!taskRunning) return;
                if (progressFile.isFile()) {
                    try (BufferedReader reader = new BufferedReader(new FileReader(progressFile))) {
                        StringBuilder progress = new StringBuilder();
                        String line;
                        while ((line = reader.readLine()) != null) progress.append(line).append('\n');
                        if (progress.length() > 0) resultText.setText("جاري التنفيذ...\n" + progress);
                    } catch (IOException ignored) { }
                }
                mainHandler.postDelayed(this, PROGRESS_REFRESH_MS);
            }
        });
    }

    private void finishAction(String result) {
        taskRunning = false;
        progressBar.setVisibility(View.GONE);
        resultText.setText(result);
        setActionButtonsEnabled(true);
        if (progressFile.exists()) progressFile.delete();
    }

    private void setActionButtonsEnabled(boolean enabled) {
        int[] ids = {R.id.btn_pick_pak, R.id.btn_unpack, R.id.btn_repack_custom, R.id.btn_stealth_repack, R.id.btn_fix_crc, R.id.btn_compile_lua, R.id.btn_decompile_lua};
        for (int id : ids) {
            View button = findViewById(id);
            if (button != null) button.setEnabled(enabled);
        }
    }

    private String formatSize(long bytes) {
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024 * 1024) return String.format("%.1f KB", bytes / 1024.0);
        if (bytes < 1024L * 1024L * 1024L) return String.format("%.2f MB", bytes / (1024.0 * 1024.0));
        return String.format("%.2f GB", bytes / (1024.0 * 1024.0 * 1024.0));
    }

    private void showToast(String message) { Toast.makeText(this, message, Toast.LENGTH_LONG).show(); }

    private interface FileSelectionCallback { void onSelected(File file); }
}
