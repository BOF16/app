# No shrinking or obfuscation is enabled for the clean build.
-keep class com.chaquo.python.** { *; }
-keep class python.tool.** { *; }
